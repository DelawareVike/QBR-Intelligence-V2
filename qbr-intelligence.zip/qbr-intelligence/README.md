# QBR Intelligence · Netlify Deploy

A QBR (Quarterly Business Review) AI analysis app that turns any CSV into strategic account insights, charts, and recommendations — powered by Claude.

## Project Structure

```
qbr-intelligence/
├── netlify.toml                  # Netlify config (publish dir, functions, headers)
├── netlify/
│   └── functions/
│       └── analyze.js            # Serverless function — keeps API key secure
└── public/
    └── index.html                # The full app
```

## Deploy to Netlify (3 steps)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial QBR Intelligence app"
git remote add origin https://github.com/YOUR_USERNAME/qbr-intelligence.git
git push -u origin main
```

### 2. Connect to Netlify
1. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import an existing project**
2. Connect your GitHub repo
3. Netlify will auto-detect `netlify.toml` — no build settings needed
4. Click **Deploy site**

### 3. Add your API Key (required for AI features)
1. In your Netlify dashboard → **Site configuration** → **Environment variables**
2. Add a new variable:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-api03-...` (your key from [console.anthropic.com](https://console.anthropic.com))
3. Trigger a **redeploy** (Deploys → Trigger deploy)

That's it. Your app is live and the API key is never exposed to the browser.

## How It Works

- **`public/index.html`** — The entire frontend: CSV upload, auto-charts, KPI cards, and AI insight UI
- **`netlify/functions/analyze.js`** — A serverless Node.js function that receives the analysis prompt from the frontend and calls the Anthropic API server-side using the environment variable. The key is never sent to the client.
- **`netlify.toml`** — Redirects `/api/*` to `/.netlify/functions/*`, sets security headers, and configures the build

## Local Development

```bash
npm install -g netlify-cli
netlify dev
```

Then open `http://localhost:8888`. The CLI will load your `.env` file if you create one:

```
# .env (never commit this)
ANTHROPIC_API_KEY=sk-ant-api03-...
```

## Features

- 📊 Auto-detects numeric, categorical, and date columns
- 📈 4 chart types: line trend, bar/histogram, doughnut, scatter
- 🔢 KPI cards with period-over-period trend indicators
- 🤖 AI-powered insights and prioritized recommendations
- 🔒 API key stored securely as an environment variable
- 📱 Responsive design
